vlog -sv -f $design/rtl.cfg
