
vsim +licq -c tb_top_opt -do sim.do

