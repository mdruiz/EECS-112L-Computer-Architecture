
ncsim -64  \
        -update \
        -licqueue \
        -64bit  \
        -input sim.do \
        work.tb_top:module
        #work.tb_top:arch
        #work.mux4to1:arch


