vlog -sv -f $verif/tb.cfg

vopt +acc tb_top -o tb_top_opt

